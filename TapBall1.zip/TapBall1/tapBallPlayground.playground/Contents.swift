import UIKit

var score = 0
var balls = 0, strikes = 0, outs = 0
var runnerOnFirst = false
var runnerOnSecond = false
var runnerOnThird = false
var inning = 1






//
//var pitchLocation: Int




// this function will move every baserunner up the number of bases
func moveUpBases (number: Int) {
    
    switch number {
        
    case 1:
        if runnerOnThird {
            score += 1
            runnerOnThird = false
        }
        if runnerOnSecond {
            runnerOnThird = true
            runnerOnSecond = false
        }
        if runnerOnFirst {
            runnerOnSecond = true
        }
        runnerOnFirst = true
        break
        
    case 2:
        if runnerOnThird {
            score += 1
            runnerOnThird = false
        }
        if runnerOnSecond {
            score += 1
            runnerOnSecond = false
        }
        if runnerOnFirst {
            runnerOnThird = true
        }
        runnerOnSecond = true
        
    case 3:
        if runnerOnThird {
            score += 1
            runnerOnThird = false
        }
        if runnerOnSecond {
            score += 1
            runnerOnSecond = false
        }
        if runnerOnFirst {
            score += 1
            runnerOnFirst = false
        }
        runnerOnThird = true
        
        
    case 4:
        if runnerOnThird {
            score += 1
            runnerOnThird = false
        }
        if runnerOnSecond {
            score += 1
            runnerOnSecond = false
        }
        if runnerOnFirst {
            score += 1
            runnerOnFirst = false
        }
        score += 1
        
    default:
        break
    }
    
    
}

func showBases () {
    
    if runnerOnFirst {
        print("Runner on first")
    }
    if runnerOnSecond {
        print("Runner on second")
    }
    if runnerOnThird {
        print("Runner on third")
    }
    
    
}

while inning < 10 {
    
    print("Inning: \(inning)\nScore: \(score)")
    while outs < 3 {
        let pitchLocation = Int.random(in: 1...9)
        let batterGuessLocation = Int.random(in: 1...9)
        let batGuesLocRight: Bool = pitchLocation == batterGuessLocation
        let pitchType = Int.random(in: 1...4)
        let batGuessType = Int.random(in: 1...4)
        let batGuesTypRight: Bool = pitchType == batGuessType
        
        // when pitcher throws the pitch
        // if the batter didn't guess anything
        // there is a 50 percent chance of it being out of the zone
        // and a 50 percent chance of it being in the zone
        let isInZone = Bool.random()
        // if it is out of the zone, a ball will be added to the box score
        if (isInZone == false) {
            print("Ball")
            balls += 1
            print("\(balls) balls and \(strikes) strikes")
            if balls > 3 {
                print("Batter walks")
                moveUpBases(number: 1)
                balls = 0
                showBases()
            }
        } else {
            // if it is in the zone, the batter will swing 80% of the time
            let batterSwung = Bool.random()
            // if the batter swings, it will result in contact 70% of the time
            if batterSwung {
                print("Batter Swings")
                let contactDecider = Int.random(in: 1 ... 10)
                let madeContact: Bool
                if contactDecider <= 5 { madeContact = true }
                else { madeContact = false }
                // if they do not make contact, a strike will be added to the box score
                if  madeContact == false {
                    strikes += 1
                    print("Swing and a miss. Strike \(strikes)")
                    if strikes > 2 {
                        print("Batter struck out")
                        outs += 1
                        strikes = 0
                        balls = 0
                        print("\(outs) Outs")
                        
                    }
                }
                // if they do make contact, there is a 70% chance that it will be an out
                if madeContact == true {
                    print("Made Contact")
                    let outDecider = Int.random(in: 1...10)
                    let madeOut: Bool
                    if (batGuesLocRight && !batGuesTypRight) || (batGuesTypRight && !batGuesLocRight) {
                        if batGuesLocRight {print("Batter Guessed Location Right")}
                        else if batGuesTypRight {print("Batter Guessed Type of Pitch Right")}
                        if outDecider <= 4 {madeOut = true}
                        else {madeOut = false}
                    }
                    else if batGuesTypRight && batGuesLocRight {
                        print("Batter Guessed Type of Pitch and Pitch Location Right")
                        if outDecider <= 9 {madeOut = true}
                        else {madeOut = false}
                    }
                    else {
                        print("Batter Guessed Both Wrong")
                        if outDecider <= 7 {madeOut = true}
                        else {madeOut = false}
                    }
                    
                    
                    
                    
                    // if it is an out, it is either a fly out or a ground out
                    if madeOut == true {
                        let isFLyout = Bool.random()
                        let isGroudout: Bool = !isFLyout
                        let pickPosition = Int.random(in: 1...9)
                        var positionString: String
                        // either way, choose which position it goes to
                        switch pickPosition {
                        case 1:
                            positionString = "Pitcher"
                        case 2:
                            positionString = "Catcher"
                        case 3:
                            positionString = "First Baseman"
                        case 4:
                            positionString = "Second Baseman"
                        case 5:
                            positionString = "Third Baseman"
                        case 6:
                            positionString = "Short Stop"
                        case 7:
                            positionString = "Left Fielder"
                        case 8:
                            positionString = "Center Fielder"
                        case 9:
                            positionString = "Right Fielder"
                            
                        default:
                            positionString = ""
                            print("error. didn't pick a position")
                        }
                        
                        if isFLyout {
                            print("Flew out to " + positionString)
                            
                        }
                        else if isGroudout {
                            print("Grounded out to " + positionString)
                        } else {
                            print("Error, neither flyout nor groundout")
                        }
                        // add 1 to outs
                        outs += 1
                        print("\(outs) outs")
                        balls = 0
                        strikes = 0
                        
                    }
                        
                    else if madeOut == false {
                        // if it is a hit, there is a 50% chance of it being a single, 25% chance of it being a double, 20% chance of it being a home run and 5% for a triple
                        let pickTypeOfHit = Int.random(in: 1...100)
                        
                        
                        switch pickTypeOfHit {
                        case 1...50:
                            print("It's a Single")
                            balls = 0
                            strikes = 0
                            // if the result is a single, each runner moves up one base
                            moveUpBases(number: 1)
                            showBases()
                            
                        case 51...75:
                            print("It's a Double")
                            balls = 0
                            strikes = 0
                            moveUpBases(number: 2)
                            showBases()
                            
                        case 76...95:
                            print("It's a Home Run!")
                            balls = 0
                            strikes = 0
                            moveUpBases(number: 4)
                            showBases()
                            
                            
                        case 96...100:
                            
                            print("It's a Triple")
                            balls = 0
                            strikes = 0
                            moveUpBases(number: 3)
                            showBases()
                        default:
                            print("error, type of hit something wrong")
                        }
                        print("Score: \(score)")
                        
                        
                    }
                        
                    else {
                        print("error, madeOut is doing something wrong")
                    }
                    
                    
                    
                    
                }
                
                
            } else {
                strikes += 1
                print("Batter takes a strike.")
                print("\(balls) balls and \(strikes) strikes")
                if strikes > 2 {
                    print("Batter struck out")
                    outs += 1
                    strikes = 0
                    balls = 0
                    print("\(outs) Outs")
                    
                }
            }
            
        }
        
    }
    outs = 0
    runnerOnFirst = false
    runnerOnSecond = false
    runnerOnThird = false
    
    inning += 1
    
}

print("Game Over\nFinal Score: \(score)")


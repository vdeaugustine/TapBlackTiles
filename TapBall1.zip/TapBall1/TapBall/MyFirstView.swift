//
//  MainView.swift
//  TapBall
//
//  Created by Vincent DeAugustine on 3/13/19.
//  Copyright © 2019 Vincent DeAugustine. All rights reserved.
//

import Foundation
import UIKit

class MyFirstView: UIViewController {
    
    // variables
    var score = 0
    var balls = 0, strikes = 0, outs = 0
    var runnerOnFirst = false
    var runnerOnSecond = false
    var runnerOnThird = false
    var inning = 1
    // default values for guesses are fastball down middle
    var locGuessed = 5
    var typeGuessed = 1
    
    @IBOutlet var fastButOutlet: UIButton!
    @IBOutlet var curvButOutlet: UIButton!
    @IBOutlet var changeButOutlet: UIButton!
    
    
    // declate box score labels
    @IBOutlet var resultLabel: UILabel!
    @IBOutlet var inningLabel: UILabel!
    @IBOutlet var ballsLabel: UILabel!
    @IBOutlet var strikesLabel: UILabel!
    @IBOutlet var outsLabel: UILabel!
    @IBOutlet var scoreLabel: UILabel!
    
    //declare strike zone buttons
    @IBOutlet var but1Outlet: UIButton!
    @IBOutlet var but2Outlet: UIButton!
    @IBOutlet var but3Outlet: UIButton!
    @IBOutlet var but4Outlet: UIButton!
    @IBOutlet var but5Outlet: UIButton!
    @IBOutlet var but6Outlet: UIButton!
    @IBOutlet var but7Outlet: UIButton!
    @IBOutlet var but8Outlet: UIButton!
    @IBOutlet var but9Outlet: UIButton!
    
    @IBAction func button1Selected(_ sender: Any) {
        locGuessed = 1
        makeAllStrikezoneGray()
        but1Outlet.backgroundColor = UIColor.blue
    
    }
    @IBAction func button2Selected(_ sender: Any) {
        locGuessed = 2
        makeAllStrikezoneGray()
        but2Outlet.backgroundColor = UIColor.blue
        
    }
    @IBAction func button3Selected(_ sender: Any) {
        locGuessed = 3
        makeAllStrikezoneGray()
        but3Outlet.backgroundColor = UIColor.blue
        
    }
    @IBAction func button4Selected(_ sender: Any) {
        locGuessed = 4
        makeAllStrikezoneGray()
        but4Outlet.backgroundColor = UIColor.blue
        
    }
    @IBAction func button5Selected(_ sender: Any) {
        locGuessed = 5
        makeAllStrikezoneGray()
        but5Outlet.backgroundColor = UIColor.blue
        
    }
    @IBAction func button6Selected(_ sender: Any) {
        locGuessed = 6
        makeAllStrikezoneGray()
        but6Outlet.backgroundColor = UIColor.blue
        
    }
    @IBAction func button7Selected(_ sender: Any) {
        locGuessed = 7
        makeAllStrikezoneGray()
        but7Outlet.backgroundColor = UIColor.blue
      
    }
    @IBAction func button8Selected(_ sender: Any) {
        locGuessed = 8
        makeAllStrikezoneGray()
        but8Outlet.backgroundColor = UIColor.blue
        
    }
    @IBAction func button9Selected(_ sender: Any) {
        locGuessed = 9
        makeAllStrikezoneGray()
        but9Outlet.backgroundColor = UIColor.blue
    }
    
    // declare guess pitch type buttons
    @IBAction func selectedFast(_ sender: Any) {
        typeGuessed = 1
        makeAllPitchTypeBoxesWhite()
        fastButOutlet.backgroundColor = UIColor.blue
        
    }
    @IBAction func selectedCurv(_ sender: Any) {
        typeGuessed = 2
        makeAllPitchTypeBoxesWhite()
        curvButOutlet.backgroundColor = UIColor.blue
        
    }
    @IBAction func selectedChange(_ sender: Any) {
        typeGuessed = 3
        makeAllPitchTypeBoxesWhite()
        changeButOutlet.backgroundColor = UIColor.blue
        
    }
    
    //declare pitch button
    
    @IBAction func pitch(_ sender: Any) {
        
        let pitchLocation = Int.random(in: 1...9)
        changeColorOfSingleStrikezoneBox(boxNumber: pitchLocation, color: .orange)
        let batGuesLocRight: Bool = pitchLocation == locGuessed
        let pitchType = Int.random(in: 1...3)
        changeColorOfPitchTypeBox(num: pitchType, color: .orange)
        
        let batGuesTypRight: Bool = pitchType == typeGuessed
        
    
            
            switch locGuessed {
            case 1:
                if batGuesLocRight {
                    but1Outlet.backgroundColor = UIColor.green
                } else {
                    but1Outlet.backgroundColor = UIColor.red
                }
            case 2:
                if batGuesLocRight {
                    but2Outlet.backgroundColor = UIColor.green
                } else {
                    but2Outlet.backgroundColor = UIColor.red
                }
            case 3:
                if batGuesLocRight {
                    but3Outlet.backgroundColor = UIColor.green
                } else {
                    but3Outlet.backgroundColor = UIColor.red
                }
            case 4:
                if batGuesLocRight {
                    but4Outlet.backgroundColor = UIColor.green
                } else {
                    but4Outlet.backgroundColor = UIColor.red
                }
            case 5:
                if batGuesLocRight {
                    but5Outlet.backgroundColor = UIColor.green
                } else {
                    but5Outlet.backgroundColor = UIColor.red
                }
            case 6:
                if batGuesLocRight {
                    but6Outlet.backgroundColor = UIColor.green
                } else {
                    but6Outlet.backgroundColor = UIColor.red
                }
            case 7:
                if batGuesLocRight {
                    but7Outlet.backgroundColor = UIColor.green
                } else {
                    but7Outlet.backgroundColor = UIColor.red
                }
            case 8:
                if batGuesLocRight {
                    but8Outlet.backgroundColor = UIColor.green
                } else {
                    but8Outlet.backgroundColor = UIColor.red
                }
            case 9:
                if batGuesLocRight {
                    but9Outlet.backgroundColor = UIColor.green
                } else {
                    but9Outlet.backgroundColor = UIColor.red
                }
            default:
                break
            }
        
        switch typeGuessed {
        case 1:
            if batGuesTypRight {
                fastButOutlet.backgroundColor = UIColor.green
            } else {
                fastButOutlet.backgroundColor = UIColor.red
            }
            
        case 2:
            if batGuesTypRight {
                curvButOutlet.backgroundColor = UIColor.green
            } else {
                curvButOutlet.backgroundColor = UIColor.red
            }
        case 3:
            if batGuesTypRight {
                changeButOutlet.backgroundColor = UIColor.green
            } else {
                changeButOutlet.backgroundColor = UIColor.red
            }
        default:
            break
        }
    
        // when pitcher throws the pitch
        // if the batter didn't guess anything
        // there is a 50 percent chance of it being out of the zone
        // and a 50 percent chance of it being in the zone
        
        let inZoneNum = Int.random(in: 1...10)
        let isInZone = inZoneNum < 7 ? true : false
        // if it is out of the zone, a ball will be added to the box score
        if (isInZone == false) {
            // it is a ball
            print("Ball")
            resultLabel.text = "Ball"
            balls += 1
            print("\(balls) balls and \(strikes) strikes")
            ballsLabel.text = "\(balls)"
            if balls > 3 {
                print("Batter walks")
                resultLabel.text = "Batter Walks"
                moveUpBases(number: 1)
                balls = 0
                showBases()
            }
        }
        else {
            // if it is in the zone, the batter will swing 80% of the time
            let batSwungNum = Int.random(in: 1...10)
            let batterSwung = batSwungNum < 9 ? true : false
            // if the batter swings, it will result in contact 70% of the time
            if batterSwung {
                print("Batter Swings")
                let contactDecider = Int.random(in: 1 ... 10)
                let madeContact: Bool
                if contactDecider <= 5 { madeContact = true }
                else { madeContact = false }
                // if they do not make contact, a strike will be added to the box score
                if  madeContact == false {
                    strikes += 1
                    strikesLabel.text = "\(strikes)"
                    print("Swing and a miss. Strike \(strikes)")
                    resultLabel.text = "Swing and a miss. Strike \(strikes)"
                    if strikes > 2 {
                        print("Batter struck out")
                        resultLabel.text = "Batter struck out"
                        outs += 1
                        outsLabel.text = "\(outs)"
                        strikes = 0
                        strikesLabel.text = "\(strikes)"
                        balls = 0
                        ballsLabel.text = "\(balls)"
                        print("\(outs) Outs")
                        
                    }
                }
                // if they do make contact, there is a 70% chance that it will be an out
                if madeContact == true {
                    print("Made Contact")
                    let outDecider = Int.random(in: 1...10)
                    let madeOut: Bool
                    if (batGuesLocRight && !batGuesTypRight) || (batGuesTypRight && !batGuesLocRight) {
                        if batGuesLocRight {
                            print("Batter Guessed Location Right")
                            switch locGuessed {
                            case 1:
                                but1Outlet.backgroundColor = UIColor.green
                            case 2:
                                but2Outlet.backgroundColor = UIColor.green
                            case 3:
                                but3Outlet.backgroundColor = UIColor.green
                            case 4:
                                but4Outlet.backgroundColor = UIColor.green
                            case 5:
                                but5Outlet.backgroundColor = UIColor.green
                            case 6:
                                but6Outlet.backgroundColor = UIColor.green
                            case 7:
                                but7Outlet.backgroundColor = UIColor.green
                            case 8:
                                but8Outlet.backgroundColor = UIColor.green
                            case 9:
                                but9Outlet.backgroundColor = UIColor.green
                            default:
                                break
                            }
                            switch typeGuessed {
                            case 1:
                                fastButOutlet.backgroundColor = UIColor.red
                            case 2:
                                curvButOutlet.backgroundColor = UIColor.red
                            case 3:
                                changeButOutlet.backgroundColor = UIColor.red
                            default:
                                break
                            }
                        }
                        else if batGuesTypRight {
                            print("Batter Guessed Type of Pitch Right")
                            switch locGuessed {
                            case 1:
                                but1Outlet.backgroundColor = UIColor.red
                            case 2:
                                but2Outlet.backgroundColor = UIColor.red
                            case 3:
                                but3Outlet.backgroundColor = UIColor.red
                            case 4:
                                but4Outlet.backgroundColor = UIColor.red
                            case 5:
                                but5Outlet.backgroundColor = UIColor.red
                            case 6:
                                but6Outlet.backgroundColor = UIColor.red
                            case 7:
                                but7Outlet.backgroundColor = UIColor.red
                            case 8:
                                but8Outlet.backgroundColor = UIColor.red
                            case 9:
                                but9Outlet.backgroundColor = UIColor.red
                            default:
                                break
                            }
                            switch typeGuessed {
                            case 1:
                                fastButOutlet.backgroundColor = UIColor.green
                            case 2:
                                curvButOutlet.backgroundColor = UIColor.green
                            case 3:
                                changeButOutlet.backgroundColor = UIColor.green
                            default:
                                break
                            }
                            
                        }
                        if outDecider <= 4 {madeOut = true}
                        else {madeOut = false}
                    }
                    else if batGuesTypRight && batGuesLocRight {
                        print("Batter Guessed Type of Pitch and Pitch Location Right")
                        if outDecider <= 9 {madeOut = true}
                        else {madeOut = false}
                        
                        switch typeGuessed {
                        case 1:
                            fastButOutlet.backgroundColor = UIColor.green
                        case 2:
                            curvButOutlet.backgroundColor = UIColor.green
                        case 3:
                            changeButOutlet.backgroundColor = UIColor.green
                        default:
                            break
                        }
                        
                        switch locGuessed {
                        case 1:
                            but1Outlet.backgroundColor = UIColor.green
                        case 2:
                            but2Outlet.backgroundColor = UIColor.green
                        case 3:
                            but3Outlet.backgroundColor = UIColor.green
                        case 4:
                            but4Outlet.backgroundColor = UIColor.green
                        case 5:
                            but5Outlet.backgroundColor = UIColor.green
                        case 6:
                            but6Outlet.backgroundColor = UIColor.green
                        case 7:
                            but7Outlet.backgroundColor = UIColor.green
                        case 8:
                            but8Outlet.backgroundColor = UIColor.green
                        case 9:
                            but9Outlet.backgroundColor = UIColor.green
                        default:
                            break
                        }
                        
                        
                        
                        
                    }
                    else {
                        print("Batter Guessed Both Wrong")
                        if outDecider <= 7 {madeOut = true}
                        else {madeOut = false}
                        
                        switch locGuessed {
                        case 1:
                            but1Outlet.backgroundColor = UIColor.red
                        case 2:
                            but2Outlet.backgroundColor = UIColor.red
                        case 3:
                            but3Outlet.backgroundColor = UIColor.red
                        case 4:
                            but4Outlet.backgroundColor = UIColor.red
                        case 5:
                            but5Outlet.backgroundColor = UIColor.red
                        case 6:
                            but6Outlet.backgroundColor = UIColor.red
                        case 7:
                            but7Outlet.backgroundColor = UIColor.red
                        case 8:
                            but8Outlet.backgroundColor = UIColor.red
                        case 9:
                            but9Outlet.backgroundColor = UIColor.red
                        default:
                            break
                        }
                        
                        switch typeGuessed {
                        case 1:
                            fastButOutlet.backgroundColor = UIColor.red
                        case 2:
                            curvButOutlet.backgroundColor = UIColor.red
                        case 3:
                            changeButOutlet.backgroundColor = UIColor.red
                        default:
                            break
                        }
                    }
                    
                    
                    
                    
                    // if it is an out, it is either a fly out or a ground out
                    if madeOut == true {
                        let isFLyout = Bool.random()
                        let isGroudout: Bool = !isFLyout
                        let pickPosition = Int.random(in: 1...9)
                        var positionString: String
                        // either way, choose which position it goes to
                        switch pickPosition {
                        case 1:
                            positionString = "Pitcher"
                        case 2:
                            positionString = "Catcher"
                        case 3:
                            positionString = "First Baseman"
                        case 4:
                            positionString = "Second Baseman"
                        case 5:
                            positionString = "Third Baseman"
                        case 6:
                            positionString = "Short Stop"
                        case 7:
                            positionString = "Left Fielder"
                        case 8:
                            positionString = "Center Fielder"
                        case 9:
                            positionString = "Right Fielder"
                            
                        default:
                            positionString = ""
                            print("error. didn't pick a position")
                        }
                        
                        if isFLyout {
                            print("Flew out to " + positionString)
                            resultLabel.text = "Flew out to " + positionString
                        }
                        else if isGroudout {
                            print("Grounded out to " + positionString)
                            resultLabel.text = "Grounded out to " + positionString
                        } else {
                            print("Error, neither flyout nor groundout")
                        }
                        // add 1 to outs
                        outs += 1
                        outsLabel.text = "\(outs)"
                        print("\(outs) outs")
                        balls = 0
                        ballsLabel.text = "\(balls)"
                        strikes = 0
                        strikesLabel.text = "\(strikes)"
                        
                    }
                        
                    else if madeOut == false {
                        // if it is a hit, there is a 50% chance of it being a single, 25% chance of it being a double, 20% chance of it being a home run and 5% for a triple
                        let pickTypeOfHit = Int.random(in: 1...100)
                        
                        
                        switch pickTypeOfHit {
                        case 1...50:
                            print("It's a Single")
                            resultLabel.text = "It's a Single"
                            balls = 0
                            ballsLabel.text = "\(balls)"
                            strikes = 0
                            strikesLabel.text = "\(strikes)"
                            // if the result is a single, each runner moves up one base
                            moveUpBases(number: 1)
                            showBases()
                            
                        case 51...75:
                            print("It's a Double")
                            resultLabel.text = "It's a Double"
                            balls = 0
                            ballsLabel.text = "\(balls)"
                            strikes = 0
                            strikesLabel.text = "\(strikes)"
                            moveUpBases(number: 2)
                            showBases()
                            
                        case 76...95:
                            print("It's a Home Run!")
                            resultLabel.text = "It's a Home Run"
                            balls = 0
                            ballsLabel.text = "\(balls)"
                            strikes = 0
                            strikesLabel.text = "\(strikes)"
                            moveUpBases(number: 4)
                            showBases()
                            
                            
                        case 96...100:
                            
                            print("It's a Triple")
                            resultLabel.text = "It's a Triple"
                            balls = 0
                            ballsLabel.text = "\(balls)"
                            strikes = 0
                            strikesLabel.text = "\(strikes)"
                            moveUpBases(number: 3)
                            showBases()
                        default:
                            print("error, type of hit something wrong")
                        }
                        print("Score: \(score)")
                        
                        
                    }
                        
                    else {
                        print("error, madeOut is doing something wrong")
                    }
                    
                }
                
                
            } else {
                strikes += 1
                print("Batter takes a strike.")
                strikesLabel.text = "\(strikes)"
                print("\(balls) balls and \(strikes) strikes")
                if strikes > 2 {
                    print("Batter struck out")
                    outs += 1
                    outsLabel.text = "\(outs)"
                    strikes = 0
                    strikesLabel.text = "\(strikes)"
                    balls = 0
                    ballsLabel.text = "\(balls)"
                    print("\(outs) Outs")
                    
                }
            }
            
        }
        
        
        
    }
    
    @IBAction func nextButtonPressed(_ sender: Any) {
        
        // make all 
        
        // reset type guessed and location guessed
    }
    
    
    // declare base icons
    @IBOutlet var firstIcon: UILabel!
    @IBOutlet var secondIcon: UILabel!
    @IBOutlet var thirdIcon: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // initialize strike zone button colors to gray default
        makeAllStrikezoneGray()
        
        // initialize strike zone buttons to say nothing
        but1Outlet.setTitle("", for: .normal)
        but2Outlet.setTitle("", for: .normal)
        but3Outlet.setTitle("", for: .normal)
        but4Outlet.setTitle("", for: .normal)
        but5Outlet.setTitle("", for: .normal)
        but6Outlet.setTitle("", for: .normal)
        but7Outlet.setTitle("", for: .normal)
        but8Outlet.setTitle("", for: .normal)
        but9Outlet.setTitle("", for: .normal)
        
        //Result text initialization
        resultLabel.text = "Play Ball!"
        
    }
    
    
    
    // this function will move every baserunner up the number of bases
    func moveUpBases (number: Int) {
        
        switch number {
            
        case 1:
            if runnerOnThird {
                score += 1
                scoreLabel.text = "\(score)"
                runnerOnThird = false
            }
            if runnerOnSecond {
                runnerOnThird = true
                runnerOnSecond = false
            }
            if runnerOnFirst {
                runnerOnSecond = true
            }
            runnerOnFirst = true
            break
            
        case 2:
            if runnerOnThird {
                score += 1
                scoreLabel.text = "\(score)"
                runnerOnThird = false
            }
            if runnerOnSecond {
                score += 1
                scoreLabel.text = "\(score)"
                runnerOnSecond = false
            }
            if runnerOnFirst {
                runnerOnThird = true
                runnerOnFirst = false
            }
            runnerOnSecond = true
            
        case 3:
            if runnerOnThird {
                score += 1
                scoreLabel.text = "\(score)"
                runnerOnThird = false
            }
            if runnerOnSecond {
                score += 1
                scoreLabel.text = "\(score)"
                runnerOnSecond = false
            }
            if runnerOnFirst {
                score += 1
                scoreLabel.text = "\(score)"
                runnerOnFirst = false
            }
            runnerOnThird = true
            
            
        case 4:
            if runnerOnThird {
                score += 1
                scoreLabel.text = "\(score)"
                runnerOnThird = false
            }
            if runnerOnSecond {
                score += 1
                scoreLabel.text = "\(score)"
                runnerOnSecond = false
            }
            if runnerOnFirst {
                score += 1
                scoreLabel.text = "\(score)"
                runnerOnFirst = false
            }
            score += 1
            scoreLabel.text = "\(score)"
            
        default:
            break
        }
        
        if runnerOnFirst {
            firstIcon.backgroundColor = UIColor.red
        }
        if runnerOnSecond {
            secondIcon.backgroundColor = UIColor.red
        }
        if runnerOnThird {
            thirdIcon.backgroundColor = UIColor.red
        }
    }
    
    func showBases () {
        
        if runnerOnFirst {
            print("Runner on first")
        }
        if runnerOnSecond {
            print("Runner on second")
        }
        if runnerOnThird {
            print("Runner on third")
        }
        
        
    }
  
    
    func changeColorOfSingleStrikezoneBox (boxNumber: Int, color: UIColor) {
        
        switch boxNumber {
        case 1:
            but1Outlet.backgroundColor = color
        case 2:
            but2Outlet.backgroundColor = color
        case 3:
            but3Outlet.backgroundColor = color
        case 4:
            but4Outlet.backgroundColor = color
        case 5:
            but5Outlet.backgroundColor = color
        case 6:
            but6Outlet.backgroundColor = color
        case 7:
            but7Outlet.backgroundColor = color
        case 8:
            but8Outlet.backgroundColor = color
        case 9:
            but9Outlet.backgroundColor = color
        default:
            break
        }
        
        
    }
    
    
    func makeAllStrikezoneGray () {
        
        but1Outlet.backgroundColor = UIColor.gray
        but2Outlet.backgroundColor = UIColor.gray
        but3Outlet.backgroundColor = UIColor.gray
        but4Outlet.backgroundColor = UIColor.gray
        but5Outlet.backgroundColor = UIColor.gray
        but6Outlet.backgroundColor = UIColor.gray
        but7Outlet.backgroundColor = UIColor.gray
        but8Outlet.backgroundColor = UIColor.gray
        but9Outlet.backgroundColor = UIColor.gray
        
    }
    
    
    func changeColorOfPitchTypeBox (num: Int, color: UIColor) {
        
        switch num {
        case 1:
            fastButOutlet.backgroundColor = color
        case 2:
            curvButOutlet.backgroundColor = color
        case 3:
            curvButOutlet.backgroundColor = color
        default:
            break
        }
    }
    
    func makeAllPitchTypeBoxesWhite () {
        fastButOutlet.backgroundColor = UIColor.white
        curvButOutlet.backgroundColor = UIColor.white
        changeButOutlet.backgroundColor = UIColor.white
        
    }
}
